﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class ProfileConfigurationResponse
    {
        public ProfileConfigurationResponse()
        {
            alert = new List<Alerts>();
        }

        public string id { get; set; }
        public List<Alerts> alert { get; set; }
    }

    public class Alerts
    {
        public string field { get; set; }
        public string value { get; set; }
        public string unit { get; set; }
        public string editable { get; set; }
    }
}