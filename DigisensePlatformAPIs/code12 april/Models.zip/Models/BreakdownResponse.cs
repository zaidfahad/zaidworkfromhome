﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    #region  MTBD Vehicle Summary Response
    public class BreakdownResponse
    {
        public double longitude { get; set; }

        public double latitude { get; set; }

        public string timestamp { get; set; }
    }
    #endregion 
   
}