﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigisensePlatformAPIs.Models
{
    public class VehicleJsonResponse
    {
        public string code { get; set; }
        public string description { get; set; }
        public string vehicleplatform { get; set; }
        public string vehiclemodel { get; set; }
        public string registrationumber { get; set; }
        public string status { get; set; }
    }
}